# EasyUIEx 1.5.0

## Usage:
	EasyUIEx支持命名空间直接调用和jquery扩展调用两种书写方式：
	
	uiEx.{methodName}(selector,[param1],....);
	
	$(selector).{methodName}([param1],....)
	
	例如：
	uiEx.treeChk(
		"#rightsTree",
		{
			url:"do/menuJson.jsp"
		},
		[11]
	);
	
	$("#rightsTree").treeChk({url:"do/menuJson.jsp"},[11]);


## Changelog

easyUI V1.5.0
	+ EasyUIEx
	+ Drag and Drop Rows in DataGrid: easyui/datagrid-dnd.js  
	+ Editable DataGrid: easyui/jquery.edatagrid.js  
	+ DeatilDataGrid: easyui/datagrid-detailview.js  
	+ Portal: easyui/jquery.portal.js  portal.css
	+ ECharts
	
	easyUI V1.4.1
	+ EasyUIEx
	+ Drag and Drop Rows in DataGrid: easyui/datagrid-dnd.js  
	+ Editable DataGrid: easyui/jquery.edatagrid.js  
	+ DeatilDataGrid: easyui/datagrid-detailview.js  
	+ Portal: easyui/jquery.portal.js  portal.css
	+ ECharts





