package cn.easy.easyuidemo.util;

import java.util.ArrayList;
import java.util.List;

import cn.easy.easyuidemo.entity.MyUsers;

public class SysData {
	public static List<MyUsers> users=new ArrayList<MyUsers>();
	static{

		for(int i=1;i<=100;i++){
			users.add(new MyUsers(i,"User_"+i,i%2==0?'男':'女',i+18,"USERS_INFO_"+i));
		}

	}
}
