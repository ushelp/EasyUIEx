package cn.easy.easyuidemo.entity;

import java.util.ArrayList;
import java.util.List;
/**
 * 权限菜单对象
 * @author Administrator
 *
 */
public class Rights {
	private int id; //菜单id
	private String text; //菜单文字
	private String url; //菜单链接
	private String state="open"; //菜单是否打开
	private String iconCls; //菜单图标
	private List<Rights> children=new ArrayList<Rights>(); //子菜单
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getIconCls() {
		return iconCls;
	}
	public void setIconCls(String iconCls) {
		this.iconCls = iconCls;
	}
	public List<Rights> getChildren() {
		return children;
	}
	public void setChildren(List<Rights> children) {
		this.children = children;
	}
	public Rights() {
		super();
	}
	public Rights(int id, String text, String state) {
		super();
		this.id = id;
		this.text = text;
		this.state = state;
	}
	public Rights(int id, String text, String url, String iconCls) {
		super();
		this.id = id;
		this.text = text;
		this.url = url;
		this.iconCls = iconCls;
	}
	
	
}
