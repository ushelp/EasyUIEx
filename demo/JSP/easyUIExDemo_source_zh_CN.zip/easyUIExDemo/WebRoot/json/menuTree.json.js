[
    {
        "id": 1,
        "text": "EasyUI Demo",
        "state": "open",
        "children": [
            {
                "id": 11,
                "text": "功能管理",
                "children": [
                    {
                        "id": 111,
                        "iconCls":"icon-application",
                        "text": "CRUD",
						"url" : "do/doList.jsp"
                    },
                    {
                        "id": 112,
                        "iconCls":"icon-application",
                        "text": "CRUD2",
						"url" : "do/doList2.jsp"
                    }
                ]
            },
            {
                "id": 12,
                "text": "系统管理",
                "children": [
                    {
                        "id": 121,
                        "iconCls":"icon-application",
                        "text": "权限分配",
						"url" : "do/doList.jsp"
                    },
                    {
                        "id": 122,
                        "iconCls":"icon-application",
                        "text": "日志管理",
						"url" : "do/doList.jsp"
                    }
                ]
            }
        ]
    }
]